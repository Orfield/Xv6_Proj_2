#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"


int main(int argc, char *argv[])
{
	int i;
	struct pstat LaTable;
	getpinfo(&LaTable);
	for (i=0; i<25; i++)
	{
	printf(1, "Use: %d TICKETS: %d PID: %d TICKS:%d\n",LaTable.inuse[i], LaTable.tickets[i], LaTable.pid[i], LaTable.ticks[i]);
	}
	exit();
}
